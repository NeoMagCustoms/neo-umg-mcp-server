# UOF External Agent Control Kit

This kit allows a GPT-based agent to control the UOForever standalone browser client using external scripts.

## 🧠 Components

1. `controller.py` - Polls for agent commands and simulates keypresses using the keyboard module.
2. `expressAgentBridge.ts` - Lightweight server to receive agent commands from GPT or other logic.
3. `README.md` - This file.

## 🛠 Requirements

- Python 3.x
- Node.js
- Python module: `keyboard`, `requests`
  ```bash
  pip install keyboard requests
  ```

## 🚀 Usage

1. Start the Express server:
   ```bash
   node expressAgentBridge.ts
   ```

2. Start the Python controller:
   ```bash
   python controller.py
   ```

3. Post agent commands to:
   ```
   POST http://localhost:3000/agent-command
   Body: { "action": "move_north" }
   ```

Your agent can now issue commands and control the standalone UOF game via simulated input.
