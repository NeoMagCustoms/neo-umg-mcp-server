# controller.py
import time
import requests
import keyboard  # pip install keyboard

def move(direction):
    key_map = {
        "north": "up",
        "south": "down",
        "east": "right",
        "west": "left"
    }
    key = key_map.get(direction)
    if key:
        keyboard.press(key)
        time.sleep(0.1)
        keyboard.release(key)
        print(f"[ACTION] Moved {direction}")

def poll_loop():
    print("[Agent Controller] Polling for commands...")
    while True:
        try:
            res = requests.get("http://localhost:3000/agent-command")
            if res.status_code == 200:
                data = res.json()
                action = data.get("action", "")
                if action.startswith("move_"):
                    direction = action.split("_")[1]
                    move(direction)
            time.sleep(1)
        except Exception as e:
            print("[ERROR]", e)
            time.sleep(2)

if __name__ == "__main__":
    poll_loop()
