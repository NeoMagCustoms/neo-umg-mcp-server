import express from 'express';
const app = express();
app.use(express.json());

let currentCommand = { action: "idle" };

app.post('/agent-command', (req, res) => {
  currentCommand = req.body;
  res.sendStatus(200);
});

app.get('/agent-command', (req, res) => {
  res.json(currentCommand);
});

app.listen(3000, () => {
  console.log('🧠 Agent Command Bridge running on http://localhost:3000');
});
