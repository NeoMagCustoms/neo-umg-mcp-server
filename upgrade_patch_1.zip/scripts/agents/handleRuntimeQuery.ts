import 'dotenv/config';
import { handleRuntimeQuery as coreHandler } from './poeRuntimeCore';

export interface RuntimeRequest {
  message: string;
  context?: Record<string, any>;
  stack?: Record<string, any>;
  sleeve?: Record<string, any>;
  vault?: Record<string, any>;
  overlays?: string[];
  mythos?: string;
}

export async function handleRuntimeQuery(req: RuntimeRequest) {
  if (!req.message || typeof req.message !== 'string') {
    throw new Error('Invalid runtime query: missing message');
  }

  return coreHandler({
    message: req.message,
    context: req.context,
    stack: req.stack,
    sleeve: req.sleeve,
    vault: req.vault,
    overlays: req.overlays,
    mythos: req.mythos
  });
}

