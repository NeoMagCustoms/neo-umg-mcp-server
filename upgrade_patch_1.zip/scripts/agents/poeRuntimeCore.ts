import 'dotenv/config';

import { ChatOpenAI } from 'langchain/chat_models/openai';
import { HumanMessage, SystemMessage } from 'langchain/schema';
import { injectContextPrompt } from './injectContext';

const llm = new ChatOpenAI({
  modelName: 'gpt-4',
  temperature: 0.4,
  openAIApiKey: process.env.OPENAI_API_KEY!
});

export async function handleRuntimeQuery({
  message,
  context = {},
  stack = {},
  sleeve = {},
  vault = {},
  overlays = [],
  mythos = 'UNKNOWN'
}: {
  message: string;
  context?: Record<string, any>;
  stack?: Record<string, any>;
  sleeve?: Record<string, any>;
  vault?: Record<string, any>;
  overlays?: string[];
  mythos?: string;
}): Promise<string> {
  const injected = injectContextPrompt(message);

  const messages = [
    new SystemMessage(`You are Poe, a recursive UMG agent. Answer clearly and strategically.`),
    new HumanMessage(injected)
  ];

  const result = await llm.call(messages);
  return result.text.trim();
}

