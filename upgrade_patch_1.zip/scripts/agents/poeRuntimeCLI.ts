import 'dotenv/config';
// scripts/agents/poeRuntimeCLI.ts

import inquirer from 'inquirer';
import chalk from 'chalk';
import { handleRuntimeQuery } from './handleRuntimeQuery';

type ConversationMessage = { role: 'user' | 'poe'; content: string };

async function main() {
  console.log(chalk.cyan('\n🤖 Talk to Poe (interactive memory mode)\n'));
  const conversation: ConversationMessage[] = [];

  while (true) {
    const { input } = await inquirer.prompt([
      {
        type: 'input',
        name: 'input',
        message: '🗣 You:',
      }
    ]);

    if (input.toLowerCase() === 'exit') {
      console.log(chalk.gray('👋 Ending conversation.'));
      break;
    }

    // Push user message into memory
    conversation.push({ role: 'user', content: input });

    const response = await handleRuntimeQuery({
      message: input,
      context: { history: [...conversation] }
    });

    conversation.push({ role: 'poe', content: response });

    console.log(chalk.green('\n🧠 Poe:\n'));
    console.log(response + '\n');
  }
}

main();

