import 'dotenv/config';
// scripts/agents/poeRouterCLI.ts

import inquirer from 'inquirer';
import chalk from 'chalk';
import { handleRuntimeQuery } from './poeRuntimeCore'; // 🧠 Local Poe
import { runNeoPoeUMGThread } from '../assistants/NeoPoeUMG'; // ✅ FIXED

async function main() {
  const { mode } = await inquirer.prompt([
    {
      type: 'list',
      name: 'mode',
      message: '💬 Choose which Poe to talk to:',
      choices: ['Local Poe', 'OpenAI Assistant']
    }
  ]);

  while (true) {
    const { input } = await inquirer.prompt([
      {
        type: 'input',
        name: 'input',
        message: `🗣 You (${mode})`
      }
    ]);

    if (input.toLowerCase() === 'exit') {
      console.log(chalk.gray('👋 Ending conversation.'));
      break;
    }

    console.log(chalk.gray('\n🧠 Thinking...\n'));
    const response =
      mode === 'Local Poe'
        ? await handleRuntimeQuery({ message: input })
        : await runNeoPoeUMGThread(input); // ✅ FIXED

    console.log(chalk.yellow(`\n${mode} says:`));
    console.log(response + '\n');
  }
}

main();

