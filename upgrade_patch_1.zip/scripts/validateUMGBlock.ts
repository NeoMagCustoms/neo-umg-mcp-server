import 'dotenv/config';
// Part of uploadCLI.ts — uses Zod validation inline
// ✅ No new file needed
