import 'dotenv/config';
import fs from 'fs';
import path from 'path';
const glob = require('glob');

// 🚦 LIVE MODE — set to true to simulate, false to apply real changes
const dryRun = false;

// Load refactor plan
const planPath = path.join(__dirname, '..', '..', 'NeoUMG_RefactorPlan.json');
const plan = JSON.parse(fs.readFileSync(planPath, 'utf-8'));

console.log(`\n🧠 Starting UMG Refactor (${plan.plan_name})\n`);

// 🧱 Safe file/folder move filtering (with proper TS type)
const validMoves = plan.moves.filter((m: { from: string; to: string }) => {
  const fromPath = path.join(__dirname, '..', '..', m.from);
  return fs.existsSync(fromPath);
});

// 🔄 Execute valid moves
for (const move of validMoves) {
  const fromPath = path.join(__dirname, '..', '..', move.from);
  const toPath = path.join(__dirname, '..', '..', move.to);

  if (dryRun) {
    console.log(`(dry-run) Would move: ${move.from} → ${move.to}`);
  } else {
    try {
      fs.renameSync(fromPath, toPath);
      console.log(`✅ Moved: ${move.from} → ${move.to}`);
    } catch (err: any) {
      console.error(`❌ Failed to move: ${move.from} → ${move.to}`, err.message);
    }
  }
}

// 🔧 Import path rewrites
for (const update of plan.import_updates) {
  const files = glob.sync(path.join(__dirname, '..', '..', '**/*.ts'));

  for (const file of files) {
    const content = fs.readFileSync(file, 'utf-8');

    if (content.includes(update.search)) {
      const updated = content.split(update.search).join(update.replace);

      if (dryRun) {
        console.log(`(dry-run) Would update imports in: ${file}`);
      } else {
        fs.writeFileSync(file, updated, 'utf-8');
        console.log(`🔧 Updated imports in: ${file}`);
      }
    }
  }
}

console.log(`\n🎯 Refactor ${dryRun ? 'dry-run complete' : 'executed'} based on: ${plan.plan_name}\n`);

