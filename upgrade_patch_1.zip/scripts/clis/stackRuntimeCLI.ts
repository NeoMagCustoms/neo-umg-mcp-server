import 'dotenv/config';
import { StackRuntimeService } from '../services/StackRuntimeService';

console.log('\n🧠 UMG Runtime Stack Viewer\n');

const stack = StackRuntimeService.getActiveStack();

if (!stack) {
  console.log('❌ No active stack found.');
  process.exit(1);
}

console.log(`📛 Stack ID: ${stack.stack_id}`);
console.log(`📝 Description: ${stack.description}\n`);

for (const [blockType, block] of Object.entries(stack.blocks)) {
  console.log(`🔹 ${blockType.toUpperCase()} — ${block.label}`);
  console.log(`   ${block.content}\n`);
}

console.log('✅ Runtime stack inspection complete.\n');
