import 'dotenv/config';
import { analyzeRepo } from '../analyzeRepo'; // ✅ Make sure this path is correct
import path from 'path';

const targetRepo = path.resolve('C:/dev/neo-blocks');  // Adjust path as needed

(async () => {
  console.log(`\n🔍 Scanning repo: ${targetRepo}`);

  const result = await analyzeRepo(targetRepo);

  if ('error' in result) {
    console.error('❌ Error:', result.error);
    return;
  }

  console.log(`\n📁 Total files: ${result.totalFiles}`);
  console.log(`\n📂 File types:`);

  Object.entries(result.fileTypes)
    .sort(([, a], [, b]) => (b as number) - (a as number))
    .forEach(([ext, count]) => {
      console.log(`  - ${ext}: ${count}`);
    });

  console.log(`\n🧱 First 10 files:\n`);
  result.files.slice(0, 10).forEach((file: string) => {
    console.log(`  • ${file}`);
  });

  console.log(`\n✅ Repo scan complete.\n`);
})();

