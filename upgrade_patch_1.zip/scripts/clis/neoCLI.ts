import 'dotenv/config';
// scripts/clis/neoCLI.ts

import readline from 'readline';
import chalk from 'chalk';
import { runNeoPoeUMGThread } from '../assistants/NeoPoeUMG';

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
  prompt: chalk.blue('\n🧠 You: ')
});

console.clear();
console.log(chalk.cyan('\n🤖 NeoPoeUMG Terminal Chat'));
console.log(chalk.gray('Type `exit` to quit.\n'));

rl.prompt();

rl.on('line', async (line) => {
  const input = line.trim();
  if (input.toLowerCase() === 'exit') {
    console.log(chalk.gray('\n👋 Ending NeoPoeUMG session.\n'));
    process.exit(0);
  }

  const response = await runNeoPoeUMGThread(input);
  rl.prompt();
}).on('close', () => {
  console.log(chalk.gray('\n👋 Session closed.'));
  process.exit(0);
});
