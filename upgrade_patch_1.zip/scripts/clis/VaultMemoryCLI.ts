import 'dotenv/config';
import { VaultService } from '../services/VaultService';

console.log('\n🧠 PoeUMG Vault Memory Snapshot\n');

function print(label: string, data: any) {
  console.log(`🔹 ${label}:`);
  console.log(JSON.stringify(data, null, 2));
  console.log('');
}

print('ALIGNMENT BLOCK', VaultService.getAlignment());
print('META.MOLT.STACK', VaultService.getMetaMOLT());
print('INSTRUCTION LAYER', VaultService.getInstructionLayer());
print('OVERLAY MODULES', VaultService.getOverlay());
print('MYTHOS BLOCK', VaultService.getMythos());

const stack = VaultService.getStack();
if (stack) {
  print('ACTIVE STACK', stack);
} else {
  console.warn('⚠️ No active stack found.');
}

console.log('✅ Memory snapshot complete.\n');
