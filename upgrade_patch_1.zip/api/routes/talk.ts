import 'dotenv/config';
// api/routes/talk.ts

import express from 'express';
import { vaultLoaderMiddleware } from '../../middleware/vaultLoaderMiddleware';
import { sleeveContextMiddleware } from '../../middleware/sleeveContextMiddleware';
import { alignmentReflectionMiddleware } from '../../middleware/alignmentReflectionMiddleware';
import { outputSanityCheckMiddleware } from '../../middleware/outputSanityCheckMiddleware';

import { handleRuntimeQuery } from '../../scripts/agents/handleRuntimeQuery';
import { runNeoPoeUMGThread } from '../../scripts/assistants/NeoPoeUMG';

const router = express.Router();

// 🧬 Order of middleware matters
router.use(vaultLoaderMiddleware);
router.use(sleeveContextMiddleware);
router.use(alignmentReflectionMiddleware);
router.use(outputSanityCheckMiddleware);

router.post('/', async (req, res) => {
  try {
    const { message, context, useNeoPoe } = req.body;

    if (!message || typeof message !== 'string') {
      return res.status(400).json({ error: 'Missing or invalid message' });
    }

    // 🌐 Route to OpenAI Assistant if specified
    if (useNeoPoe) {
      await runNeoPoeUMGThread(message);
      return res.json({ status: '✅ Routed to NeoPoeUMG (OpenAI Assistant)' });
    }

    // 🧠 Local Poe Runtime
    const result = await handleRuntimeQuery({
      message,
      context,
      stack: req.stack,
      sleeve: req.sleeve,
      vault: req.vault,
      overlays: req.context?.overlay ? [req.context.overlay] : [],
      mythos: req.context?.mythos?.ORIGIN || 'UNKNOWN'
    });

    res.json({
      status: '🧠 Poe response via /talk',
      result
    });

  } catch (err: any) {
    console.error('❌ /talk error:', err.message);
    res.status(500).json({ error: err.message || 'Internal Server Error' });
  }
});

export default router;

