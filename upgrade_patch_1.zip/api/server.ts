/// <reference path="../types/express/index.d.ts" />  // 👈 Ensures custom Express typings load
import 'dotenv/config';

import express from 'express';
import cors from 'cors';
import path from 'path';

import sseRoute from './routes/sse';
import mcpRoute from './routes/mcp';
import scaffoldRoute from './routes/scaffold';
import talkRoute from './routes/talk';


const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());

// Serve UI
const staticDir = path.join(__dirname, '..', 'public');
app.use(express.static(staticDir));
app.get('/', (_req, res) => {
  res.sendFile(path.join(staticDir, 'index.html'));
});

// Optional API key check
app.use((req, res, next) => {
  const key = req.headers['x-api-key'];
  if (process.env.API_KEY && key !== process.env.API_KEY) {
    return res.status(403).json({ error: 'Unauthorized' });
  }
  next();
});

// Routes
app.use('/scaffold', scaffoldRoute);
app.use('/talk', talkRoute);
app.use('/', sseRoute);
app.use('/', mcpRoute);

// Final fallback
app.use((_req, res) => {
  res.status(404).send('🧠 UMG MCP route not found.');
});

app.listen(PORT, () => {
  console.log(`🧠 Neo UMG MCP Server running at http://localhost:${PORT}`);
});

